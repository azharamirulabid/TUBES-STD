#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED

#include <iostream>

using namespace std;

int selectMenu();

#endif // MENU_H_INCLUDED
